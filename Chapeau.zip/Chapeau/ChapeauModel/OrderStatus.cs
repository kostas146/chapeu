﻿namespace ChapeauModel
{
    public enum OrderStatus
    {
        Taken = 1,
        inPreperation = 2,
        Finished = 3
    }
}
