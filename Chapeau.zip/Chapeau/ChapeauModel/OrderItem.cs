﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChapeauModel
{
    public class OrderItem
    {
        public int Order_id { get; set; }
        public int MenuItem { get; set; }
        public int State { get; set; }
        public DateTime Time { get; set; }
        public int Count { get; set; }
        public string Comment { get; set; }
        public int Tablenumber { get; set; }
        public bool Occupied { get; set; }
        public string Name { get; set; }
        public OrderItem(int order_id, int menuItem, int state, DateTime time, int count, string comment, int tablenr, bool occupied,string name)
        {
            Order_id = order_id;
            MenuItem = menuItem;
            State = state;
            Time = time;
            Count = count;
            Comment = comment;
            Tablenumber = tablenr;
            Occupied = occupied;
            Name = name;
        }
    }
}
