﻿using ChapeauDAL;
using ChapeauModel;
using System;
using System.Collections.Generic;

namespace ChapeauLogic
{
    public class Order_Service
    {
        private Order_DAO order_db = new Order_DAO();

        private List<Order> orders;
        private List<OrderItem> order_item;
        public List<Order> GetOrders()
        {
            try
            {
                orders = order_db.Db_Get_All_Orders();
                return orders;
            }
            catch (Exception e)
            {
                throw new Exception("Chapeau application couldn't connect to the database. Therefore we can't retrieve the orders data.");
            }

        }
        public List<OrderItem> GetOrderItems()
        {
            try
            {
                order_item = order_db.Db_Get_OrdersItems();
                return order_item;
            }
            catch (Exception e)
            {
                throw new Exception("Chapeau application couldn't connect to the database. Therefore we can't retrieve the orders data.");
            }

        }

        public List<OrderItem> GetOrderItemsbyTable(int tablenr)
        {
            
                 return order_db.Db_Get_OrdersItemsbyTableNumber(tablenr);
        

        }


    }
}
