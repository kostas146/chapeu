﻿using ChapeauDAL;
using ChapeauModel;
using System;
using System.Collections.Generic;

namespace ChapeauLogic
{
    public class Employee_Service
    {
        private Employee_DAO employee_db = new Employee_DAO();
        private Employee employee;
        public Employee GetEmployee(string name)
        {
            try
            {
                employee = employee_db.Db_Get_Employee(name);
                return employee;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
    }
}
