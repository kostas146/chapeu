﻿using ChapeauDAL;
using ChapeauModel;
using ChapeauModel.Menu;
using System;
using System.Collections.Generic;

namespace ChapeauLogic
{
    public class Menu_Service
    {
        private Menu_DAO Menu_db = new Menu_DAO();
        private List<MainMenu> menus;
        public List<MainMenu> GetFullMenu()
        {
            try
            {
                menus = Menu_db.Db_Get_All_FullMenu();
                return menus;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
    }
}
