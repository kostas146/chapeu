﻿using System.Drawing;

namespace ChapeauUserControl.Abstract
{
    public enum EnumColors
    {
        Primary,
        Secondary,
        Tetriary,
        Body
    }
    public class Colors
    {
        public Color primary = ColorTranslator.FromHtml("#626262");
        public Color secondary = ColorTranslator.FromHtml("#856453");
        public Color tetriary = ColorTranslator.FromHtml("#213122");
        public Color body = ColorTranslator.FromHtml("#000000");
    }
}
