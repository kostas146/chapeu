﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ChapeauUserControl.Abstract;

namespace ChapeauUserControl.Layout
{
    public partial class NavigationItem : UserControl
    {
        private readonly Colors colors = new Colors();
        public NavigationItem()
        {
            InitializeComponent();
            activeBorder.BackColor = colors.primary;
        }
        private string navigationText;
        public string NavigationText { 
            get { return navigationText; } 
            set { lbl_navigation.Text = value; navigationText = value; } 
        }

        public void ItemActiveState(bool isActive)
        {
            if (isActive)
            {
                activeBorder.Show();
                BackColor = ColorTranslator.FromHtml("#F8F8F8");
            } else
            {
                activeBorder.Hide();
                BackColor = Color.Transparent;
            }
        }
    }
}
