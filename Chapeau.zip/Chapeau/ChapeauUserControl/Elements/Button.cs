﻿using ChapeauUserControl.Abstract;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace ChapeauUserControl
{
    public class Button2 : Button
    {
        private EnumColors style = EnumColors.Primary;
        private bool isOutline = false;
        private readonly Colors colors = new Colors();

        [Description("Button style displayed in the application"), Category("Appearance"), Browsable(true)]
        public EnumColors Style
        {
            get { return style; }
            set
            {
                style = value;
                ForeColor = GetColor(value);
                IsOutline = isOutline;
            }
        }

        [Description("Button has border style"), Category("Appearance"), Browsable(true)]
        public bool IsOutline
        {
            get { return isOutline; }
            set
            {
                if (value)
                {
                    BackColor = Color.Transparent;
                    ForeColor = GetColor(style);
                    FlatAppearance.BorderSize = 1;
                }
                else
                {
                    BackColor = GetColor(style);
                    ForeColor = Color.White;
                    FlatAppearance.BorderSize = 0;
                }

                isOutline = value;
            }
        }

        private Color GetColor(EnumColors value)
        {
            Color color;

            switch (value)
            {
                case EnumColors.Primary:
                    color = colors.primary;
                    break;
                case EnumColors.Secondary:
                    color = colors.secondary;
                    break;
                default:
                    color = colors.tetriary;
                    break;
            }

            return color;
        }
        public Button2()
        {
            FlatStyle = FlatStyle.Flat;
            Size = new Size(100, 30);
            UseVisualStyleBackColor = true;
            Font = new Font("Arial", 12, FontStyle.Regular);
        }
    }
}
