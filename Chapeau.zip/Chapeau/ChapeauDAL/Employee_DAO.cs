﻿using ChapeauModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace ChapeauDAL
{
    public class Employee_DAO : Base
    {
        public Employee Db_Get_Employee(string name)
        {
            string query = $"SELECT employee_id, name, password, role FROM Employee WHERE Employee.name = '{name}'";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTable(ExecuteSelectQuery(query, sqlParameters));
        }

        private Employee ReadTable(DataTable dataTable)
        {
            DataRow row = dataTable.Rows[0];

            Employee employee = new Employee((int)row["employee_id"], row["name"].ToString(), (int)row["role"], (int)row["password"]);
            return employee; // fix
        }
    }
}
