﻿using ChapeauModel;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System;

namespace ChapeauDAL
{
    public class Order_DAO : Base
    {
        public List<Order> Db_Get_All_Orders()
        {
            string query = @"
                SELECT * FROM [Order] 
                    inner join Restaurant_Table
                        on [Order].table_number = Restaurant_Table.table_number 
                    inner join Employee 
                        on [Order].employee_id = Employee.employee_id";

            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }


        public List<Order> Db_Get_Orders_Of_Specific_Table(int tableNumber)
        {
            string query = "SELECT * FROM [Order] WHERE table_number = @table_number";
            SqlParameter[] sqlParameters = new SqlParameter[1]{
                new SqlParameter("@table_number", tableNumber)
            };

            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }

        private List<Order> ReadTables(DataTable dataTable)
        {
            List<Order> orders = new List<Order>();

            foreach (DataRow dr in dataTable.Rows)
            {
                RestaurantTable table = new RestaurantTable(
                    (int)dr["table_number"],
                    (bool)dr["is_occupied"],
                    (int)dr["number_of_seats"]
                );

                Employee employee = new Employee(
                    (int)dr["employee_id"],
                    dr["name"].ToString(),
                    (int)dr["role"],
                    (int)dr["password"]
                );

                Order order = new Order(
                    (int)dr["order_id"],
                    table,
                    employee,
                    new List<OrderItem>(),
                    (bool)dr["is_payed"],
                    (decimal)dr["tip"],
                    (decimal)dr["total_cost"],
                    (string)dr["feedback"]


                );


                orders.Add(order);
            }
            return orders;
        }

        public List<OrderItem> Db_Get_OrdersItems()
        {
          
            string query = "SELECT order_id,menu_item_id, order_status, time_order_taken, count, comment FROM Order_Item";
          
            SqlParameter[] sqlParameters = new SqlParameter[0];

            return ReadTable(ExecuteSelectQuery(query, sqlParameters));
        }

        public List<OrderItem> Db_Get_OrdersItemsbyTableNumber(int TableNr)
        {

            string query = @"SELECT Order_Item.order_id, order_status, time_order_taken, count, comment, Restaurant_Table.table_number, Restaurant_Table.is_occupied,Menu_Item.menu_item_id,Menu_Item.item_name from Order_Item
              INNER JOIN [Order] ON Order_Item.order_id = [Order].order_id
              INNER JOIN [Restaurant_Table] ON [Order].table_number = Restaurant_Table.table_number
              INNER JOIN [Menu_item] ON [Order_Item].menu_item_id = Menu_Item.menu_item_id
            WHERE [Order].table_number = @tableno";

            SqlParameter[] sqlParameters = new SqlParameter[1]{
        new SqlParameter("@tableno", TableNr)
    };

            return ReadTable(ExecuteSelectQuery(query, sqlParameters));
        }

        private List<OrderItem> ReadTable(DataTable dataTable)
        {
            List<OrderItem> item = new List<OrderItem>();
            foreach (DataRow dr in dataTable.Rows)
            {
                OrderItem items = new OrderItem(
                 (int)dr["order_id"],
                 (int)dr["menu_item_id"],
                 (int)dr["order_status"],
                 (DateTime)dr["time_order_taken"],
                 (int)dr["count"],
                (string)dr["comment"],
                (int)dr["table_number"],
                (bool)dr["is_occupied"],
                (string)dr["item_name"]
                 );

                item.Add(items);
            }
            return item;
        }
    }
}
