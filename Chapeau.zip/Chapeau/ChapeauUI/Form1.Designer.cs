﻿namespace ChapeauUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanelOrders = new System.Windows.Forms.FlowLayoutPanel();
            this.lbl_employee = new System.Windows.Forms.Label();
            this.pnl_navigation = new System.Windows.Forms.Panel();
            this.LogoutButton = new ChapeauUserControl.Button2();
            this.navigationItemManagement = new ChapeauUserControl.Layout.NavigationItem();
            this.navigationItemOrders = new ChapeauUserControl.Layout.NavigationItem();
            this.navigationOverviewLogin = new ChapeauUserControl.Layout.NavigationItem();
            this.button21 = new ChapeauUserControl.Button2();
            this.input1 = new ChapeauUserControl.Elements.Form.Input();
            this.login1 = new ChapeauUI.Pages.Login();
            this.overview2 = new ChapeauUI.Pages.Overview();
            this.pnl_navigation.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanelOrders
            // 
            this.flowLayoutPanelOrders.AutoScroll = true;
            this.flowLayoutPanelOrders.Location = new System.Drawing.Point(1323, 830);
            this.flowLayoutPanelOrders.Margin = new System.Windows.Forms.Padding(4);
            this.flowLayoutPanelOrders.Name = "flowLayoutPanelOrders";
            this.flowLayoutPanelOrders.Size = new System.Drawing.Size(573, 394);
            this.flowLayoutPanelOrders.TabIndex = 5;
            // 
            // lbl_employee
            // 
            this.lbl_employee.AutoSize = true;
            this.lbl_employee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employee.Location = new System.Drawing.Point(1299, 773);
            this.lbl_employee.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_employee.Name = "lbl_employee";
            this.lbl_employee.Size = new System.Drawing.Size(64, 25);
            this.lbl_employee.TabIndex = 6;
            this.lbl_employee.Text = "label1";
            // 
            // pnl_navigation
            // 
            this.pnl_navigation.BackColor = System.Drawing.Color.White;
            this.pnl_navigation.Controls.Add(this.LogoutButton);
            this.pnl_navigation.Controls.Add(this.navigationItemManagement);
            this.pnl_navigation.Controls.Add(this.navigationItemOrders);
            this.pnl_navigation.Controls.Add(this.navigationOverviewLogin);
            this.pnl_navigation.Location = new System.Drawing.Point(0, 0);
            this.pnl_navigation.Margin = new System.Windows.Forms.Padding(4);
            this.pnl_navigation.Name = "pnl_navigation";
            this.pnl_navigation.Size = new System.Drawing.Size(340, 945);
            this.pnl_navigation.TabIndex = 8;
            // 
            // LogoutButton
            // 
            this.LogoutButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(98)))), ((int)(((byte)(98)))));
            this.LogoutButton.FlatAppearance.BorderSize = 0;
            this.LogoutButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LogoutButton.Font = new System.Drawing.Font("Arial", 12F);
            this.LogoutButton.ForeColor = System.Drawing.Color.White;
            this.LogoutButton.IsOutline = false;
            this.LogoutButton.Location = new System.Drawing.Point(3, 470);
            this.LogoutButton.Name = "LogoutButton";
            this.LogoutButton.Size = new System.Drawing.Size(323, 53);
            this.LogoutButton.Style = ChapeauUserControl.Abstract.EnumColors.Primary;
            this.LogoutButton.TabIndex = 12;
            this.LogoutButton.Text = "LogoutButton";
            this.LogoutButton.UseVisualStyleBackColor = false;
            this.LogoutButton.Click += new System.EventHandler(this.LogoutButton_Click);
            // 
            // navigationItemManagement
            // 
            this.navigationItemManagement.BackColor = System.Drawing.Color.Transparent;
            this.navigationItemManagement.Location = new System.Drawing.Point(0, 297);
            this.navigationItemManagement.Margin = new System.Windows.Forms.Padding(0);
            this.navigationItemManagement.Name = "navigationItemManagement";
            this.navigationItemManagement.NavigationText = "Management";
            this.navigationItemManagement.Size = new System.Drawing.Size(340, 68);
            this.navigationItemManagement.TabIndex = 2;
            this.navigationItemManagement.Click += new System.EventHandler(this.navigationItemManagement_Click);
            // 
            // navigationItemOrders
            // 
            this.navigationItemOrders.BackColor = System.Drawing.Color.Transparent;
            this.navigationItemOrders.Location = new System.Drawing.Point(0, 225);
            this.navigationItemOrders.Margin = new System.Windows.Forms.Padding(5);
            this.navigationItemOrders.Name = "navigationItemOrders";
            this.navigationItemOrders.NavigationText = "Orders";
            this.navigationItemOrders.Size = new System.Drawing.Size(340, 68);
            this.navigationItemOrders.TabIndex = 1;
            this.navigationItemOrders.Click += new System.EventHandler(this.navigationItemOrders_Click);
            // 
            // navigationOverviewLogin
            // 
            this.navigationOverviewLogin.BackColor = System.Drawing.Color.Transparent;
            this.navigationOverviewLogin.Location = new System.Drawing.Point(0, 150);
            this.navigationOverviewLogin.Margin = new System.Windows.Forms.Padding(5);
            this.navigationOverviewLogin.Name = "navigationOverviewLogin";
            this.navigationOverviewLogin.NavigationText = "Overview";
            this.navigationOverviewLogin.Size = new System.Drawing.Size(340, 68);
            this.navigationOverviewLogin.TabIndex = 0;
            this.navigationOverviewLogin.Click += new System.EventHandler(this.navigationItemOverview_Click);
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.Transparent;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.button21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(98)))), ((int)(((byte)(98)))));
            this.button21.IsOutline = true;
            this.button21.Location = new System.Drawing.Point(1323, 660);
            this.button21.Margin = new System.Windows.Forms.Padding(4);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(133, 37);
            this.button21.Style = ChapeauUserControl.Abstract.EnumColors.Primary;
            this.button21.TabIndex = 2;
            this.button21.Text = "button21";
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // input1
            // 
            this.input1.Font = new System.Drawing.Font("Arial", 12F);
            this.input1.ForeColor = System.Drawing.Color.Gray;
            this.input1.Location = new System.Drawing.Point(1367, 857);
            this.input1.Margin = new System.Windows.Forms.Padding(4);
            this.input1.MinimumSize = new System.Drawing.Size(132, 40);
            this.input1.Name = "input1";
            this.input1.PlaceholderText = "Testing";
            this.input1.Size = new System.Drawing.Size(132, 30);
            this.input1.TabIndex = 0;
            this.input1.Text = "Testing";
            // 
            // login1
            // 
            this.login1.Location = new System.Drawing.Point(333, 0);
            this.login1.Margin = new System.Windows.Forms.Padding(4);
            this.login1.Name = "login1";
            this.login1.Size = new System.Drawing.Size(1019, 523);
            this.login1.TabIndex = 9;
            // 
            // overview2
            // 
            this.overview2.Location = new System.Drawing.Point(334, 0);
            this.overview2.Margin = new System.Windows.Forms.Padding(5);
            this.overview2.Name = "overview2";
            this.overview2.Size = new System.Drawing.Size(942, 536);
            this.overview2.TabIndex = 7;
            
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1365, 945);
            this.Controls.Add(this.login1);
            this.Controls.Add(this.overview2);
            this.Controls.Add(this.pnl_navigation);
            this.Controls.Add(this.lbl_employee);
            this.Controls.Add(this.flowLayoutPanelOrders);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.input1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.pnl_navigation.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ChapeauUserControl.Elements.Form.Input input1;
        private ChapeauUserControl.Button2 button21;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelOrders;
        private System.Windows.Forms.Label lbl_employee;
        private Pages.Overview overview2;
        public System.Windows.Forms.Panel pnl_navigation;
        private ChapeauUserControl.Layout.NavigationItem navigationItemManagement;
        private ChapeauUserControl.Layout.NavigationItem navigationItemOrders;
        private ChapeauUserControl.Layout.NavigationItem navigationOverviewLogin;

        private Pages.Login login1;
        private ChapeauUserControl.Button2 LogoutButton;
    }
}

