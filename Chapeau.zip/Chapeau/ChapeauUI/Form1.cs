﻿using ChapeauLogic;
using ChapeauModel;
using ChapeauUserControl.Components;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChapeauUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            changeSpecificNavItemState("Overview");

            Menu_Service menu_service = new Menu_Service();

            List<ChapeauModel.Menu.MainMenu> listmainmenu = menu_service.GetFullMenu();

            
            Console.WriteLine(listmainmenu);

            //       pnl_navigation.Hide(); How to hide menu and show it after you are logged in

            overview2.Show();
            login1.Show(); 
            
      
        }



    

        private void button21_Click(object sender, EventArgs e)
        {
          
        }

        #region Navigation

        private void navigationItemOverview_Click(object sender, EventArgs e)
        {
            changeSpecificNavItemState("Overview");
            
            login1.Hide();
        }

        private void navigationItemOrders_Click(object sender, EventArgs e)
        {
            changeSpecificNavItemState("Orders");
        }

        private void navigationItemManagement_Click(object sender, EventArgs e)
        {
            changeSpecificNavItemState("Management");
        }
     
        private void changeSpecificNavItemState(string itemName)
        {
            SetDefaultNavItemStates();

            if (itemName == "Overview")
            {
                navigationOverviewLogin.ItemActiveState(true);
            }
            else if (itemName == "Orders")
            {
                navigationItemOrders.ItemActiveState(true);
            }
            else if (itemName == "Management")
            {
                navigationItemManagement.ItemActiveState(true);
             
            }
          

        }

        private void SetDefaultNavItemStates()
        {
         
            navigationOverviewLogin.ItemActiveState(false);
     
            navigationItemOrders.ItemActiveState(false);
            navigationItemManagement.ItemActiveState(false);
        }





        #endregion Navigation

  

        private void LogoutButton_Click(object sender, EventArgs e)
        {
            login1.Show();
           
        }

       

    
    }
    }
