﻿using ChapeauLogic;
using ChapeauModel;
using System;
using System.Windows.Forms;

namespace ChapeauUI.Pages
{
    public partial class Login : UserControl

    {

        public Employee employee;
        public Login()
        { 
            InitializeComponent();

            CheckBox checkBox = new CheckBox();
            checkBox1.Appearance = Appearance.Button;
        }

        public void Verify()
        {
            Employee_Service employee_service = new Employee_Service();
            Employee employee = employee_service.GetEmployee(usernameinput.Text);

            if (usernameinput.Text == employee.EmployeeName && passwordinput.Text == employee.Password.ToString())
            {
                this.Hide();
                Form1 NewForm = new Form1();
                NewForm.ShowDialog();

                usernameinput.Text = "";
                passwordinput.Text = "";
            }
            else if (usernameinput.Text == "")
            {
                usernametest.Text = "Please enter something";

            }
            else
            {
                usernametest.Text = "Wrong username or password";

                passwordinput.Text = "";
            }

        }


        private void LoginButton_Click(object sender, EventArgs e)
        {
            Verify();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                passwordinput.UseSystemPasswordChar = false;
            }
            else
            {
                passwordinput.UseSystemPasswordChar = true;
            }

        }



        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
