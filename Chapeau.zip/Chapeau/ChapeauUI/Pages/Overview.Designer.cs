﻿namespace ChapeauUI.Pages
{
    partial class Overview
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_overview = new System.Windows.Forms.Panel();
            this.overview2 = new System.Windows.Forms.Panel();
            this.Displaylistview = new System.Windows.Forms.ListView();
            this.TableNr = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.State = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Times = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.MenuItem = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.time = new ChapeauUserControl.Elements.TextLabel();
            this.Status1 = new System.Windows.Forms.Label();
            this.Refreshview = new ChapeauUserControl.Button2();
            this.Status10 = new System.Windows.Forms.Label();
            this.Status9 = new System.Windows.Forms.Label();
            this.Status8 = new System.Windows.Forms.Label();
            this.Status7 = new System.Windows.Forms.Label();
            this.Status4 = new System.Windows.Forms.Label();
            this.Status5 = new System.Windows.Forms.Label();
            this.Status6 = new System.Windows.Forms.Label();
            this.Status3 = new System.Windows.Forms.Label();
            this.Status2 = new System.Windows.Forms.Label();
            this.Table10 = new System.Windows.Forms.Button();
            this.Table9 = new System.Windows.Forms.Button();
            this.Table8 = new System.Windows.Forms.Button();
            this.Table7 = new System.Windows.Forms.Button();
            this.Table6 = new System.Windows.Forms.Button();
            this.Table5 = new System.Windows.Forms.Button();
            this.Table4 = new System.Windows.Forms.Button();
            this.Table3 = new System.Windows.Forms.Button();
            this.Table2 = new System.Windows.Forms.Button();
            this.Table1 = new System.Windows.Forms.Button();
            this.textHeading1 = new ChapeauUserControl.Elements.TextHeading();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button21 = new ChapeauUserControl.Button2();
            this.lbl_name = new ChapeauUserControl.Elements.TextBody();
            this.textBody1 = new ChapeauUserControl.Elements.TextBody();
            this.lbl_overview = new ChapeauUserControl.Elements.TextHeading();
            this.pnl_overview.SuspendLayout();
            this.overview2.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_overview
            // 
            this.pnl_overview.Controls.Add(this.overview2);
            this.pnl_overview.Controls.Add(this.button5);
            this.pnl_overview.Controls.Add(this.button4);
            this.pnl_overview.Controls.Add(this.button3);
            this.pnl_overview.Controls.Add(this.button2);
            this.pnl_overview.Controls.Add(this.button1);
            this.pnl_overview.Controls.Add(this.checkBox1);
            this.pnl_overview.Controls.Add(this.button21);
            this.pnl_overview.Controls.Add(this.lbl_name);
            this.pnl_overview.Controls.Add(this.textBody1);
            this.pnl_overview.Controls.Add(this.lbl_overview);
            this.pnl_overview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_overview.Location = new System.Drawing.Point(0, 0);
            this.pnl_overview.Margin = new System.Windows.Forms.Padding(4);
            this.pnl_overview.Name = "pnl_overview";
            this.pnl_overview.Size = new System.Drawing.Size(1365, 945);
            this.pnl_overview.TabIndex = 0;
            // 
            // overview2
            // 
            this.overview2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.overview2.Controls.Add(this.Displaylistview);
            this.overview2.Controls.Add(this.time);
            this.overview2.Controls.Add(this.Status1);
            this.overview2.Controls.Add(this.Refreshview);
            this.overview2.Controls.Add(this.Status10);
            this.overview2.Controls.Add(this.Status9);
            this.overview2.Controls.Add(this.Status8);
            this.overview2.Controls.Add(this.Status7);
            this.overview2.Controls.Add(this.Status4);
            this.overview2.Controls.Add(this.Status5);
            this.overview2.Controls.Add(this.Status6);
            this.overview2.Controls.Add(this.Status3);
            this.overview2.Controls.Add(this.Status2);
            this.overview2.Controls.Add(this.Table10);
            this.overview2.Controls.Add(this.Table9);
            this.overview2.Controls.Add(this.Table8);
            this.overview2.Controls.Add(this.Table7);
            this.overview2.Controls.Add(this.Table6);
            this.overview2.Controls.Add(this.Table5);
            this.overview2.Controls.Add(this.Table4);
            this.overview2.Controls.Add(this.Table3);
            this.overview2.Controls.Add(this.Table2);
            this.overview2.Controls.Add(this.Table1);
            this.overview2.Controls.Add(this.textHeading1);
            this.overview2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.overview2.Location = new System.Drawing.Point(0, 0);
            this.overview2.Margin = new System.Windows.Forms.Padding(4);
            this.overview2.Name = "overview2";
            this.overview2.Size = new System.Drawing.Size(1365, 945);
            this.overview2.TabIndex = 10;
            this.overview2.Paint += new System.Windows.Forms.PaintEventHandler(this.overview_panel_Paint);
            // 
            // Displaylistview
            // 
            this.Displaylistview.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.TableNr,
            this.State,
            this.Times,
            this.MenuItem});
            this.Displaylistview.HideSelection = false;
            this.Displaylistview.Location = new System.Drawing.Point(421, 174);
            this.Displaylistview.Name = "Displaylistview";
            this.Displaylistview.Size = new System.Drawing.Size(389, 243);
            this.Displaylistview.TabIndex = 33;
            this.Displaylistview.UseCompatibleStateImageBehavior = false;
            this.Displaylistview.View = System.Windows.Forms.View.Details;
            // 
            // TableNr
            // 
            this.TableNr.Text = "TableNr";
            // 
            // State
            // 
            this.State.Text = "state";
            // 
            // Times
            // 
            this.Times.Text = "Time";
            // 
            // MenuItem
            // 
            this.MenuItem.Text = "MenuItem";
            // 
            // time
            // 
            this.time.AutoSize = true;
            this.time.Font = new System.Drawing.Font("Arial", 12F);
            this.time.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.time.Location = new System.Drawing.Point(417, 138);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(119, 23);
            this.time.TabIndex = 32;
            this.time.Text = "Time waiting";
            // 
            // Status1
            // 
            this.Status1.AutoSize = true;
            this.Status1.Location = new System.Drawing.Point(198, 138);
            this.Status1.Name = "Status1";
            this.Status1.Size = new System.Drawing.Size(56, 17);
            this.Status1.TabIndex = 29;
            this.Status1.Text = "Status1";
            // 
            // Refreshview
            // 
            this.Refreshview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(98)))), ((int)(((byte)(98)))));
            this.Refreshview.FlatAppearance.BorderSize = 0;
            this.Refreshview.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Refreshview.Font = new System.Drawing.Font("Arial", 12F);
            this.Refreshview.ForeColor = System.Drawing.Color.White;
            this.Refreshview.IsOutline = false;
            this.Refreshview.Location = new System.Drawing.Point(279, 88);
            this.Refreshview.Name = "Refreshview";
            this.Refreshview.Size = new System.Drawing.Size(136, 45);
            this.Refreshview.Style = ChapeauUserControl.Abstract.EnumColors.Primary;
            this.Refreshview.TabIndex = 25;
            this.Refreshview.Text = "Refresh";
            this.Refreshview.UseVisualStyleBackColor = true;
            this.Refreshview.Click += new System.EventHandler(this.Refreshview_Click);
            // 
            // Status10
            // 
            this.Status10.AutoSize = true;
            this.Status10.Location = new System.Drawing.Point(198, 499);
            this.Status10.Name = "Status10";
            this.Status10.Size = new System.Drawing.Size(64, 17);
            this.Status10.TabIndex = 24;
            this.Status10.Text = "Status10";
            // 
            // Status9
            // 
            this.Status9.AutoSize = true;
            this.Status9.Location = new System.Drawing.Point(198, 461);
            this.Status9.Name = "Status9";
            this.Status9.Size = new System.Drawing.Size(56, 17);
            this.Status9.TabIndex = 23;
            this.Status9.Text = "Status9";
            // 
            // Status8
            // 
            this.Status8.AutoSize = true;
            this.Status8.Location = new System.Drawing.Point(198, 419);
            this.Status8.Name = "Status8";
            this.Status8.Size = new System.Drawing.Size(56, 17);
            this.Status8.TabIndex = 22;
            this.Status8.Text = "Status8";
            // 
            // Status7
            // 
            this.Status7.AutoSize = true;
            this.Status7.Location = new System.Drawing.Point(198, 376);
            this.Status7.Name = "Status7";
            this.Status7.Size = new System.Drawing.Size(56, 17);
            this.Status7.TabIndex = 21;
            this.Status7.Text = "Status7";
            // 
            // Status4
            // 
            this.Status4.AutoSize = true;
            this.Status4.Location = new System.Drawing.Point(198, 259);
            this.Status4.Name = "Status4";
            this.Status4.Size = new System.Drawing.Size(56, 17);
            this.Status4.TabIndex = 20;
            this.Status4.Text = "Status4";
            // 
            // Status5
            // 
            this.Status5.AutoSize = true;
            this.Status5.Location = new System.Drawing.Point(198, 297);
            this.Status5.Name = "Status5";
            this.Status5.Size = new System.Drawing.Size(56, 17);
            this.Status5.TabIndex = 19;
            this.Status5.Text = "Status5";
            // 
            // Status6
            // 
            this.Status6.AutoSize = true;
            this.Status6.Location = new System.Drawing.Point(198, 334);
            this.Status6.Name = "Status6";
            this.Status6.Size = new System.Drawing.Size(56, 17);
            this.Status6.TabIndex = 18;
            this.Status6.Text = "Status6";
            // 
            // Status3
            // 
            this.Status3.AutoSize = true;
            this.Status3.Location = new System.Drawing.Point(198, 214);
            this.Status3.Name = "Status3";
            this.Status3.Size = new System.Drawing.Size(56, 17);
            this.Status3.TabIndex = 17;
            this.Status3.Text = "Status3";
            // 
            // Status2
            // 
            this.Status2.AutoSize = true;
            this.Status2.Location = new System.Drawing.Point(198, 174);
            this.Status2.Name = "Status2";
            this.Status2.Size = new System.Drawing.Size(56, 17);
            this.Status2.TabIndex = 16;
            this.Status2.Text = "Status2";
            // 
            // Table10
            // 
            this.Table10.Location = new System.Drawing.Point(99, 493);
            this.Table10.Name = "Table10";
            this.Table10.Size = new System.Drawing.Size(75, 23);
            this.Table10.TabIndex = 14;
            this.Table10.Text = "Table10";
            this.Table10.UseVisualStyleBackColor = true;
            this.Table10.Click += new System.EventHandler(this.Table10_Click);
            // 
            // Table9
            // 
            this.Table9.Location = new System.Drawing.Point(99, 455);
            this.Table9.Name = "Table9";
            this.Table9.Size = new System.Drawing.Size(75, 23);
            this.Table9.TabIndex = 13;
            this.Table9.Text = "Table9";
            this.Table9.UseVisualStyleBackColor = true;
            this.Table9.Click += new System.EventHandler(this.Table9_Click);
            // 
            // Table8
            // 
            this.Table8.Location = new System.Drawing.Point(99, 416);
            this.Table8.Name = "Table8";
            this.Table8.Size = new System.Drawing.Size(75, 23);
            this.Table8.TabIndex = 12;
            this.Table8.Text = "Table8";
            this.Table8.UseVisualStyleBackColor = true;
            this.Table8.Click += new System.EventHandler(this.Table8_Click);
            // 
            // Table7
            // 
            this.Table7.Location = new System.Drawing.Point(99, 376);
            this.Table7.Name = "Table7";
            this.Table7.Size = new System.Drawing.Size(75, 23);
            this.Table7.TabIndex = 11;
            this.Table7.Text = "Table7";
            this.Table7.UseVisualStyleBackColor = true;
            this.Table7.Click += new System.EventHandler(this.Table7_Click);
            // 
            // Table6
            // 
            this.Table6.Location = new System.Drawing.Point(99, 334);
            this.Table6.Name = "Table6";
            this.Table6.Size = new System.Drawing.Size(75, 23);
            this.Table6.TabIndex = 10;
            this.Table6.Text = "Table6";
            this.Table6.UseVisualStyleBackColor = true;
            this.Table6.Click += new System.EventHandler(this.Table6_Click);
            // 
            // Table5
            // 
            this.Table5.Location = new System.Drawing.Point(99, 291);
            this.Table5.Name = "Table5";
            this.Table5.Size = new System.Drawing.Size(75, 23);
            this.Table5.TabIndex = 9;
            this.Table5.Text = "Table5";
            this.Table5.UseVisualStyleBackColor = true;
            this.Table5.Click += new System.EventHandler(this.Table5_Click);
            // 
            // Table4
            // 
            this.Table4.Location = new System.Drawing.Point(99, 253);
            this.Table4.Name = "Table4";
            this.Table4.Size = new System.Drawing.Size(75, 23);
            this.Table4.TabIndex = 8;
            this.Table4.Text = "Table4";
            this.Table4.UseVisualStyleBackColor = true;
            this.Table4.Click += new System.EventHandler(this.Table4_Click);
            // 
            // Table3
            // 
            this.Table3.Location = new System.Drawing.Point(99, 214);
            this.Table3.Name = "Table3";
            this.Table3.Size = new System.Drawing.Size(75, 23);
            this.Table3.TabIndex = 7;
            this.Table3.Text = "Table3";
            this.Table3.UseVisualStyleBackColor = true;
            this.Table3.Click += new System.EventHandler(this.Table3_Click);
            // 
            // Table2
            // 
            this.Table2.Location = new System.Drawing.Point(99, 174);
            this.Table2.Name = "Table2";
            this.Table2.Size = new System.Drawing.Size(75, 23);
            this.Table2.TabIndex = 6;
            this.Table2.Text = "Table2";
            this.Table2.UseVisualStyleBackColor = true;
            this.Table2.Click += new System.EventHandler(this.Table2_Click);
            // 
            // Table1
            // 
            this.Table1.Location = new System.Drawing.Point(99, 132);
            this.Table1.Name = "Table1";
            this.Table1.Size = new System.Drawing.Size(75, 23);
            this.Table1.TabIndex = 5;
            this.Table1.Text = "Table1";
            this.Table1.UseVisualStyleBackColor = true;
            this.Table1.Click += new System.EventHandler(this.Table1_Click);
            // 
            // textHeading1
            // 
            this.textHeading1.AutoSize = true;
            this.textHeading1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.textHeading1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(98)))), ((int)(((byte)(98)))));
            this.textHeading1.Location = new System.Drawing.Point(93, 60);
            this.textHeading1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textHeading1.Name = "textHeading1";
            this.textHeading1.Size = new System.Drawing.Size(151, 35);
            this.textHeading1.TabIndex = 0;
            this.textHeading1.Text = "Overview";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(99, 291);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 9;
            this.button5.Text = "button5";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(99, 253);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 8;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(99, 214);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 7;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(99, 174);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 6;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(99, 132);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 5;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(402, 176);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(98, 21);
            this.checkBox1.TabIndex = 4;
            this.checkBox1.Text = "checkBox1";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.Transparent;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Font = new System.Drawing.Font("Arial", 12F);
            this.button21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(98)))), ((int)(((byte)(98)))));
            this.button21.IsOutline = true;
            this.button21.Location = new System.Drawing.Point(645, 107);
            this.button21.Margin = new System.Windows.Forms.Padding(4);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(295, 48);
            this.button21.Style = ChapeauUserControl.Abstract.EnumColors.Primary;
            this.button21.TabIndex = 3;
            this.button21.Text = "Get employee name";
            this.button21.UseVisualStyleBackColor = false;
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Font = new System.Drawing.Font("Arial", 14F);
            this.lbl_name.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl_name.Location = new System.Drawing.Point(1046, 227);
            this.lbl_name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(78, 27);
            this.lbl_name.TabIndex = 2;
            this.lbl_name.Text = "empty";
            // 
            // textBody1
            // 
            this.textBody1.AutoSize = true;
            this.textBody1.Font = new System.Drawing.Font("Arial", 14F);
            this.textBody1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.textBody1.Location = new System.Drawing.Point(1046, 150);
            this.textBody1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textBody1.Name = "textBody1";
            this.textBody1.Size = new System.Drawing.Size(75, 27);
            this.textBody1.TabIndex = 1;
            this.textBody1.Text = "Name";
            // 
            // lbl_overview
            // 
            this.lbl_overview.AutoSize = true;
            this.lbl_overview.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.lbl_overview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(98)))), ((int)(((byte)(98)))));
            this.lbl_overview.Location = new System.Drawing.Point(93, 60);
            this.lbl_overview.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_overview.Name = "lbl_overview";
            this.lbl_overview.Size = new System.Drawing.Size(151, 35);
            this.lbl_overview.TabIndex = 0;
            this.lbl_overview.Text = "Overview";
            // 
            // Overview
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnl_overview);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Overview";
            this.Size = new System.Drawing.Size(1365, 945);
            this.pnl_overview.ResumeLayout(false);
            this.pnl_overview.PerformLayout();
            this.overview2.ResumeLayout(false);
            this.overview2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_overview;
        private ChapeauUserControl.Elements.TextHeading lbl_overview;
        private ChapeauUserControl.Elements.TextBody lbl_name;
        private ChapeauUserControl.Elements.TextBody textBody1;
        private ChapeauUserControl.Button2 button21;
        private System.Windows.Forms.Panel overview2;
        private System.Windows.Forms.Button Table5;
        private System.Windows.Forms.Button Table4;
        private System.Windows.Forms.Button Table3;
        private System.Windows.Forms.Button Table2;
        private System.Windows.Forms.Button Table1;
        private ChapeauUserControl.Elements.TextHeading textHeading1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button Table10;
        private System.Windows.Forms.Button Table9;
        private System.Windows.Forms.Button Table8;
        private System.Windows.Forms.Button Table7;
        private System.Windows.Forms.Button Table6;
        private ChapeauUserControl.Button2 Refreshview;
        private System.Windows.Forms.Label Status10;
        private System.Windows.Forms.Label Status9;
        private System.Windows.Forms.Label Status8;
        private System.Windows.Forms.Label Status7;
        private System.Windows.Forms.Label Status4;
        private System.Windows.Forms.Label Status5;
        private System.Windows.Forms.Label Status6;
        private System.Windows.Forms.Label Status3;
        private System.Windows.Forms.Label Status2;
        private System.Windows.Forms.Label Status1;
        private ChapeauUserControl.Elements.TextLabel time;
        private System.Windows.Forms.ListView Displaylistview;
        private System.Windows.Forms.ColumnHeader TableNr;
        private System.Windows.Forms.ColumnHeader State;
        private System.Windows.Forms.ColumnHeader Times;
        private System.Windows.Forms.ColumnHeader MenuItem;
    }
}
