﻿using ChapeauLogic;
using ChapeauModel;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ChapeauUI.Pages
{
    public partial class Overview : UserControl
    {

        public Overview()
        {
            InitializeComponent();
            GetSetformation();

        }

        public void GetSetformation()
        {
            Button[] butts = new Button[10] { Table1, Table2, Table3, Table4, Table5, Table6, Table7, Table8, Table9, Table10 };
            Label[] labels = new Label[10] { Status1, Status2, Status3, Status4, Status5, Status6, Status7, Status8, Status9, Status10 };


            for (int x = 0; x < labels.Length; x++)
            {
                labels[x].Text = "Free";
                labels[x].ForeColor = System.Drawing.Color.DarkOrange;

            } // by default
            Order_Service order_service = new Order_Service();

            for (int tableNr = 0; tableNr <= labels.Length + 1; tableNr++) // looping to check all order from table list one by one
            {
                List<OrderItem> ByTableNr = order_service.GetOrderItemsbyTable(tableNr + 1); //filling the list
                foreach (OrderItem table in ByTableNr) //setting status 
                {

                    if (table.Occupied == true)
                    {
                        labels[tableNr].Text = "Occupied";
                        labels[tableNr].ForeColor = System.Drawing.Color.DarkGray;
                    }
                    if (table.State == (int)OrderStatus.Finished)
                    {
                        labels[tableNr].Text = "Order is ready";
                        labels[tableNr].ForeColor = System.Drawing.Color.Green;
                    }

                    if (table.State == (int)OrderStatus.inPreperation)
                    {
                        labels[tableNr].Text = "Order is in preperation";
                        labels[tableNr].ForeColor = System.Drawing.Color.Yellow;
                    }

                    if (table.State == (int)OrderStatus.Taken)
                    {
                        labels[tableNr].Text = "Order taken";
                        labels[tableNr].ForeColor = System.Drawing.Color.Black;
                    }


                }  
            }    
        }

        public void Buttons(int TableNumber)
        {
            Displaylistview.Items.Clear();
            DateTime Now = DateTime.Now;
            Order_Service order_service = new Order_Service();
            List<OrderItem> ByTableNr = order_service.GetOrderItemsbyTable(TableNumber); //filling the list
            foreach (OrderItem OrderState in ByTableNr) //setting status 
            {
                ListViewItem Display = new ListViewItem(OrderState.Tablenumber.ToString());

                OrderStatus foo = (OrderStatus)OrderState.State;
                Display.SubItems.Add(foo.ToString());
                Display.SubItems.Add(OrderState.Time.ToString("HH:mm:ss"));
                Display.SubItems.Add(OrderState.Name);
                Displaylistview.Items.Add(Display);

                TimeSpan value = OrderState.Time.Subtract(Now); //substracting now from database time
                time.Text = "Order was taken:" + value.ToString();
            }



        }
    
        private void Refreshview_Click(object sender, EventArgs e)
        {
            GetSetformation();
        }

        private void Table1_Click(object sender, EventArgs e)
        {

            Buttons(1);
        }

        private void Table2_Click(object sender, EventArgs e)
        {

            Buttons(2);
        }

        private void Table3_Click(object sender, EventArgs e)
        {

            Buttons(3);
        }

        private void Table4_Click(object sender, EventArgs e)
        {
            Buttons(4);
        }

        private void Table5_Click(object sender, EventArgs e)
        {
            Buttons(5);
        }

        private void Table6_Click(object sender, EventArgs e)
        {
            Buttons(6);
        }

        private void Table7_Click(object sender, EventArgs e)
        {
            Buttons(7);
        }

        private void Table8_Click(object sender, EventArgs e)
        {
            Buttons(8);
        }

        private void Table9_Click(object sender, EventArgs e)
        {
            Buttons(9);
        }

        private void Table10_Click(object sender, EventArgs e)
        {
            Buttons(10);
        }

        private void overview_panel_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}